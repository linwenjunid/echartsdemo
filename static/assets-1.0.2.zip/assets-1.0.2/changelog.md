# Change log

## 1.0.2 - 12.05.2018

adding echarts-china-counties-js and echarts-themes-js

## 1.0.1 - 10.03.2018

adding echarts-china-misc-js and echarts-united-kingdom-js

## 1.0.0 - 27.02.2018

jupyter-echarts, echarts-countries-js, echarts-china-provinces-js and echarts-china-cities-js
