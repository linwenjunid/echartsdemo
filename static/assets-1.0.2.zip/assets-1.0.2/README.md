# assets

For django and Flask developers, this project is the turn key solution for hosting pyecharts javascript assets. It
can be placed as it is into your server and its gh-pages acts as the default content delivery host when you evaluate pyecharts for web purposes.

## license

It includes echarts from Baidu Inc.
